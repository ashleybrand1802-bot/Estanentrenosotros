/**
 * Retro-Futuristic Terminal Sound Synthesizer
 * Pure Web Audio API - No external audio files needed
 */
class TerminalAudio {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    this.scannerOsc = null;
    this.scannerGain = null;
  }

  init() {
    if (!this.ctx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        this.ctx = new AudioContext();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggle() {
    this.enabled = !this.enabled;
    if (!this.enabled && this.scannerOsc) {
      this.stopScannerHum();
    }
    return this.enabled;
  }

  // Soft high-tech terminal keyclick
  playKeyClick() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1200, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(400, this.ctx.currentTime + 0.04);
    
    gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.04);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.04);
  }

  // Hover tone
  playHover() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, this.ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(920, this.ctx.currentTime + 0.03);

    gain.gain.setValueAtTime(0.03, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.03);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.03);
  }

  // Confirmation / Data registered sound
  playConfirm() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.setValueAtTime(660, now + 0.05);
    osc.frequency.setValueAtTime(880, now + 0.1);

    gain.gain.setValueAtTime(0.06, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.18);
  }

  // Processing telemetry chatter (computer calculating)
  playProcessing() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    for (let i = 0; i < 4; i++) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const startTime = now + i * 0.07;

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(600 + Math.random() * 800, startTime);

      gain.gain.setValueAtTime(0.04, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.05);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.05);
    }
  }

  // Low ambient scanner hum
  startScannerHum() {
    if (!this.enabled || this.scannerOsc) return;
    this.init();
    if (!this.ctx) return;

    try {
      this.scannerOsc = this.ctx.createOscillator();
      this.scannerGain = this.ctx.createGain();

      this.scannerOsc.type = 'sine';
      this.scannerOsc.frequency.setValueAtTime(80, this.ctx.currentTime);

      this.scannerGain.gain.setValueAtTime(0.015, this.ctx.currentTime);

      this.scannerOsc.connect(this.scannerGain);
      this.scannerGain.connect(this.ctx.destination);

      this.scannerOsc.start();
    } catch (e) {
      console.warn('Audio Context restriction', e);
    }
  }

  stopScannerHum() {
    if (this.scannerOsc) {
      try {
        this.scannerOsc.stop();
        this.scannerOsc.disconnect();
      } catch (e) {}
      this.scannerOsc = null;
      this.scannerGain = null;
    }
  }

  // Counter tick for points tallying
  playScoreTick() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(950, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + 0.025);

    gain.gain.setValueAtTime(0.04, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.025);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.025);
  }

  // Final classification status fanfare/alarm
  playStatusResult(status) {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    if (status === 'HUMANO' || status === 'HUMAN') {
      // Harmonious ascending chime (C5, E5, G5)
      [523.25, 659.25, 783.99].forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const startTime = now + idx * 0.12;

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.08, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(startTime);
        osc.stop(startTime + 0.35);
      });
    } else if (status === 'INVESTIGACIÓN' || status === 'REVIEW') {
      // Caution double pulse (Amber)
      [587.33, 440.00].forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const startTime = now + idx * 0.18;

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.09, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.22);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(startTime);
        osc.stop(startTime + 0.22);
      });
    } else {
      // ALIEN: Harsh dissonant klaxon alarm (Red)
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc1.type = 'sawtooth';
      osc2.type = 'square';

      osc1.frequency.setValueAtTime(220, now);
      osc1.frequency.linearRampToValueAtTime(440, now + 0.3);
      osc2.frequency.setValueAtTime(233.08, now); // Dissonant minor second
      osc2.frequency.linearRampToValueAtTime(466.16, now + 0.3);

      gain.gain.setValueAtTime(0.14, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.65);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.65);
      osc2.stop(now + 0.65);
    }
  }

  // Critical System Breakdown / Paradox Alarm
  playSystemError() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    // Heavy sub bass drone
    const subOsc = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    subOsc.type = 'sawtooth';
    subOsc.frequency.setValueAtTime(110, now);
    subOsc.frequency.exponentialRampToValueAtTime(45, now + 1.2);
    subGain.gain.setValueAtTime(0.2, now);
    subGain.gain.exponentialRampToValueAtTime(0.01, now + 1.2);

    subOsc.connect(subGain);
    subGain.connect(this.ctx.destination);
    subOsc.start(now);
    subOsc.stop(now + 1.2);

    // Distorted alarm burst
    for (let i = 0; i < 3; i++) {
      const alarmOsc = this.ctx.createOscillator();
      const alarmGain = this.ctx.createGain();
      const alertTime = now + (i * 0.28);

      alarmOsc.type = 'square';
      alarmOsc.frequency.setValueAtTime(880, alertTime);
      alarmOsc.frequency.setValueAtTime(440, alertTime + 0.12);

      alarmGain.gain.setValueAtTime(0.12, alertTime);
      alarmGain.gain.exponentialRampToValueAtTime(0.001, alertTime + 0.24);

      alarmOsc.connect(alarmGain);
      alarmGain.connect(this.ctx.destination);

      alarmOsc.start(alertTime);
      alarmOsc.stop(alertTime + 0.24);
    }
  }
}

// Global instance
window.terminalAudio = new TerminalAudio();
