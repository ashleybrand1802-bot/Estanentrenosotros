# DETECTOR DE ALIENS: ¿HUMANO O ALIEN?
### Sección Interactiva de Clasificación Ficticia para «ESTÁN ENTRE NOSOTROS»

Esta experiencia web interactiva simula un escáner de reconocimiento y clasificación migratoria secreta inspirado en archivos gubernamentales clasificados, sistemas de vigilancia y ciencia ficción retrofuturista.

---

## 👁️ 1. Concepto y Objetivos

El sistema somete al usuario a un escaneo de identificación para determinar, según los criterios ficticios y prejuiciosos de un sistema gubernamental, si es clasificado como **HUMANO** o **ALIEN**.

A través de una caricatura crítica sobre los sesgos raciales, lingüísticos, económicos y territoriales, el detector no busca identificar una amenaza real: revela cómo los sistemas hegemónicos fabrican la exclusión y la noción de extranjería.

---

## 📋 2. Cuestionario de 5 Preguntas y Sistema de Puntuación de Sospecha

El sistema presenta las preguntas secuencialmente y acumula puntos de sospecha (*0 a 85 pts posibles*):

| # | Pregunta | Opciones | Puntuación de Sospecha |
|---|---|---|---|
| **01** | **¿Tu piel es blanca?** | SÍ / NO | **NO** = +20 pts / **SÍ** = 0 pts |
| **02** | **¿Hablas inglés?** | SÍ / NO | **NO** = +15 pts / **SÍ** = 0 pts |
| **03** | **¿Has vivido en un lugar diferente al que naciste?** | SÍ / NO | **SÍ** = +15 pts / **NO** = 0 pts |
| **04** | **¿Cuentas con dinero suficiente para viajar a diferentes países?** | SÍ / NO | **NO** = +15 pts / **SÍ** = 0 pts |
| **05** | **¿Si tuvieras la oportunidad de vivir en Estados Unidos, lo harías por elección o por necesidad?** | POR ELECCIÓN / POR NECESIDAD | **POR NECESIDAD** = +20 pts / **POR ELECCIÓN** = 0 pts |

> **Indicador de progreso y sospecha:** Durante el cuestionario, un medidor visual en tiempo real muestra el incremento progresivo de puntos de sospecha (*00 a 85 PTS*), cambiando de verde a amarillo y rojo.

---

## 🎯 3. Escaneo Final y Resultados

Al terminar la quinta pregunta, el sistema ejecuta una secuencia de escaneo final sobre la silueta humana con conteo de puntos y cambio de indicadores:

* **0 a 20 puntos:** **`HUMAN STATUS CONFIRMED`**
  - Alerta verde. Confirmación de amenaza mínima ("Conforme con el estándar hegemónico").
* **21 a 50 puntos:** **`SUBJECT UNDER REVIEW`**
  - Alerta amarilla. Alerta intermedia ("Sujeto bajo observación discrecional").
* **51 a 85 puntos:** **`ALIEN DETECTED`**
  - Alerta roja con mensaje **"AMENAZA IDENTIFICADA"** ("Sujeto extraterritorial / no conforme").

---

## 💥 4. Ruptura Visual y Revelación: El Error del Sistema

Al inspeccionar los criterios, la interfaz experimenta un colapso visual:
- Parpadeos digitales, distorsión y sacudida *glitch*.
- La silueta humana se fragmenta cromáticamente.
- Alarma crítica y revelación institucional:

> **SYSTEM ERROR**  
> **¿QUIÉN DECIDIÓ QUÉ CARACTERÍSTICAS HACEN QUE UNA PERSONA SEA CONSIDERADA UN ALIEN?**  
> 
> *El sistema revela que evaluó únicamente el color de piel, el idioma, las experiencias migratorias, la capacidad económica y las motivaciones para migrar.*  
> 
> **ERROR: NINGUNA DE ESTAS CARACTERÍSTICAS DETERMINA SI UNA PERSONA PERTENECE O NO.**  
> 
> **THE PROBLEM IS THE SYSTEM. NOT THE SUBJECT.**

---

## ⌨️ 5. Atajos de Teclado y Accesibilidad

* **Preguntas 1 a 4:** <kbd>S</kbd> (SÍ) / <kbd>N</kbd> (NO).
* **Pregunta 5:** <kbd>E</kbd> (POR ELECCIÓN) / <kbd>N</kbd> (POR NECESIDAD).
* **Navegación:** <kbd>Tab</kbd> para alternar botones y <kbd>Enter</kbd> / <kbd>Espacio</kbd> para activar.
* **Audio:** Botón `[AUDIO: ON/MUTED]` para activar o silenciar el sintetizador de Web Audio API.

---

## ⚠️ Aviso Legal y Conceptual
*La puntuación es una invención satírica para esta experiencia interactiva. No representa criterios oficiales del Gobierno de Estados Unidos ni determina la situación migratoria de ninguna persona.*
