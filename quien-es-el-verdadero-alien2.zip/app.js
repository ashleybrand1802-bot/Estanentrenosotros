/**
 * DETECTOR DE ALIENS: ¿HUMANO O ALIEN?
 * Experiencia Interactiva y Contranarrativa Crítica
 * Implementación con GSAP 3 y JavaScript Moderno
 */

class AlienScannerExperience {
  constructor() {
    // Definición estricta de las 5 preguntas del sistema satírico
    this.questions = [
      {
        id: 1,
        text: "¿Tu piel es blanca?",
        subtext: "EVALUACIÓN FENOTÍPICA DE PERFILAMIENTO RACIAL",
        options: [
          { text: "SÍ", points: 0, key: "S" },
          { text: "NO", points: 20, key: "N" }
        ],
        criteriaLabel: "Color de piel"
      },
      {
        id: 2,
        text: "¿Hablas inglés?",
        subtext: "VERIFICACIÓN DE LENGUAJE HEGEMÓNICO Y ASIMILACIÓN",
        options: [
          { text: "SÍ", points: 0, key: "S" },
          { text: "NO", points: 15, key: "N" }
        ],
        criteriaLabel: "Idioma"
      },
      {
        id: 3,
        text: "¿Has vivido en un lugar diferente al que naciste?",
        subtext: "DETECCIÓN DE ANTECEDENTES DE MOVILIDAD HUMANA Y MIGRACIÓN",
        options: [
          { text: "SÍ", points: 15, key: "S" },
          { text: "NO", points: 0, key: "N" }
        ],
        criteriaLabel: "Movilidad territorial"
      },
      {
        id: 4,
        text: "¿Cuentas con dinero suficiente para viajar a diferentes países?",
        subtext: "FILTRADO POR ESTRATIFICACIÓN SOCIOECONÓMICA Y SOLVENCIA",
        options: [
          { text: "SÍ", points: 0, key: "S" },
          { text: "NO", points: 15, key: "N" }
        ],
        criteriaLabel: "Capacidad económica"
      },
      {
        id: 5,
        text: "¿Si tuvieras la oportunidad de vivir en Estados Unidos, lo harías por elección o por necesidad?",
        subtext: "DIAGNÓSTICO DE MOTIVACIÓN MIGRATORIA Y PRIVILEGIO",
        options: [
          { text: "POR ELECCIÓN", points: 0, key: "E" },
          { text: "POR NECESIDAD", points: 20, key: "N" }
        ],
        criteriaLabel: "Motivación migratoria"
      }
    ];

    // Estado de la aplicación
    this.currentQuestionIndex = 0;
    this.userAnswers = [];
    this.totalSuspicionScore = 0;
    this.isProcessing = false;
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Elementos del DOM
    this.dom = {
      body: document.body,
      // Pantallas
      screenIntro: document.getElementById('screenIntro'),
      screenQuestions: document.getElementById('screenQuestions'),
      screenFinalResult: document.getElementById('screenFinalResult'),
      screenError: document.getElementById('screenError'),
      // Botones
      btnStartScan: document.getElementById('btnStartScan'),
      btnOption1: document.getElementById('btnOption1'),
      btnOption2: document.getElementById('btnOption2'),
      btnKey1: document.getElementById('btnKey1'),
      btnKey2: document.getElementById('btnKey2'),
      btnText1: document.getElementById('btnText1'),
      btnText2: document.getElementById('btnText2'),
      btnRevealError: document.getElementById('btnRevealError'),
      btnRetry: document.getElementById('btnRetry'),
      btnRestart: document.getElementById('btnRestart'),
      audioToggleBtn: document.getElementById('audioToggleBtn'),
      // Elementos de preguntas
      questionCounter: document.getElementById('questionCounter'),
      suspicionScoreVal: document.getElementById('suspicionScoreVal'),
      suspicionMeterFill: document.getElementById('suspicionMeterFill'),
      progressBarFill: document.getElementById('progressBarFill'),
      questionCard: document.getElementById('questionCard'),
      questionText: document.getElementById('questionText'),
      questionSubtext: document.getElementById('questionSubtext'),
      processingOverlay: document.getElementById('processingOverlay'),
      processingMsg: document.getElementById('processingMsg'),
      processingSub: document.getElementById('processingSub'),
      // Elementos de resultado final
      finalScanPhaseMsg: document.getElementById('finalScanPhaseMsg'),
      finalScoreDisplay: document.getElementById('finalScoreDisplay'),
      resultStamp: document.getElementById('resultStamp'),
      resultSubBadge: document.getElementById('resultSubBadge'),
      criteriaSummaryGrid: document.getElementById('criteriaSummaryGrid'),
      // Elementos de ruptura y error
      silhouetteSvg: document.querySelector('.silhouette-svg'),
      scannerViewport: document.getElementById('scannerViewport'),
      errorHeadline: document.getElementById('errorHeadline'),
      revelationQuestion: document.getElementById('revelationQuestion'),
      finalPunchline: document.getElementById('finalPunchline'),
      // Telemetría
      terminalLogs: document.getElementById('terminalLogs'),
      answeredCount: document.getElementById('answeredCount'),
      subjectStatus: document.getElementById('subjectStatus'),
      threatLevel: document.getElementById('threatLevel'),
      telemetrySuspicion: document.getElementById('telemetrySuspicion'),
      systemClock: document.getElementById('systemClock'),
      laserScanner: document.getElementById('laserScanner'),
      bodyGeometry: document.getElementById('bodyGeometry'),
      radarSweep: document.getElementById('radarSweep'),
      azimuthVal: document.getElementById('azimuthVal')
    };

    // Timelines de GSAP
    this.laserTimeline = null;
    this.radarTimeline = null;

    // Inicializar la experiencia
    this.init();
  }

  init() {
    this.initClock();
    this.initBackgroundAnimations();
    this.initEventListeners();
    this.logTerminal("INICIO_SISTEMA: PROTOCOLO ACTIVO");
    this.logTerminal("SISTEMA DE CLASIFICACIÓN MIGRATORIA EN ESPERA");
  }

  /**
   * Reloj en vivo y telemetría de radar
   */
  initClock() {
    const updateTime = () => {
      const now = new Date();
      const h = String(now.getUTCHours()).padStart(2, '0');
      const m = String(now.getUTCMinutes()).padStart(2, '0');
      const s = String(now.getUTCSeconds()).padStart(2, '0');
      if (this.dom.systemClock) {
        this.dom.systemClock.textContent = `${h}:${m}:${s} HORA ESTÁNDAR`;
      }
    };
    updateTime();
    setInterval(updateTime, 1000);
  }

  /**
   * Animaciones de fondo del Escáner y Telemetría con GSAP
   */
  initBackgroundAnimations() {
    if (this.reducedMotion) return;

    // 1. Rayo láser vertical continuo recorriendo la silueta humana
    if (this.dom.laserScanner) {
      this.laserTimeline = gsap.timeline({ repeat: -1, yoyo: true });
      this.laserTimeline.to(this.dom.laserScanner, {
        y: 400,
        duration: 3.2,
        ease: "power1.inOut"
      });
    }

    // 2. Giro del vector de barrido del Radar HUD
    if (this.dom.radarSweep) {
      this.radarTimeline = gsap.to(this.dom.radarSweep, {
        rotation: 360,
        transformOrigin: "50px 50px",
        duration: 4,
        ease: "none",
        repeat: -1,
        onUpdate: () => {
          if (this.dom.azimuthVal && Math.random() > 0.85) {
            this.dom.azimuthVal.textContent = `${(Math.random() * 360).toFixed(1)}°`;
          }
        }
      });
    }

    // 3. Animación de entrada de la silueta humana
    if (this.dom.bodyGeometry) {
      gsap.from(this.dom.bodyGeometry, {
        opacity: 0,
        scale: 0.95,
        duration: 1.5,
        ease: "power2.out",
        transformOrigin: "center center"
      });
    }
  }

  /**
   * Registro de eventos del usuario
   */
  initEventListeners() {
    // Botón Iniciar Escaneo
    this.dom.btnStartScan.addEventListener('click', () => {
      this.playSound('confirm');
      this.startQuestionFlow();
    });

    // Botones dinámicos de respuesta
    this.dom.btnOption1.addEventListener('click', () => this.handleOptionSelection(0));
    this.dom.btnOption2.addEventListener('click', () => this.handleOptionSelection(1));

    // Botón para inspeccionar criterios / desencadenar ruptura
    this.dom.btnRevealError.addEventListener('click', () => {
      this.playSound('click');
      this.triggerVisualRupture();
    });

    // Botones finales
    this.dom.btnRetry.addEventListener('click', () => {
      this.playSound('confirm');
      this.resetToQuestions();
    });

    this.dom.btnRestart.addEventListener('click', () => {
      this.playSound('confirm');
      this.resetToIntro();
    });

    // Toggle de audio
    this.dom.audioToggleBtn.addEventListener('click', () => {
      const active = window.terminalAudio.toggle();
      const label = this.dom.audioToggleBtn.querySelector('.audio-label');
      const icon = this.dom.audioToggleBtn.querySelector('.audio-icon');
      if (label) label.textContent = active ? 'AUDIO: ACTIVADO' : 'AUDIO: SILENCIADO';
      if (icon) icon.textContent = active ? '[🔊]' : '[🔇]';
      if (active) this.playSound('click');
    });

    // Efecto de sonido al pasar el cursor sobre cualquier botón
    const buttons = document.querySelectorAll('.cyber-btn');
    buttons.forEach(btn => {
      btn.addEventListener('mouseenter', () => this.playSound('hover'));
    });

    // Accesibilidad por teclado (Teclas S, N, E, Y, Espacio, Enter)
    window.addEventListener('keydown', (e) => {
      if (this.isProcessing) return;

      const isQuestionsScreen = this.dom.screenQuestions.classList.contains('active');
      if (!isQuestionsScreen) return;

      const currentQ = this.questions[this.currentQuestionIndex];
      const key = e.key.toLowerCase();

      if (currentQ.id === 5) {
        // Para la pregunta 5: E = Elección, N = Necesidad
        if (key === 'e') {
          e.preventDefault();
          this.dom.btnOption1.focus();
          this.handleOptionSelection(0);
        } else if (key === 'n') {
          e.preventDefault();
          this.dom.btnOption2.focus();
          this.handleOptionSelection(1);
        }
      } else {
        // Para las preguntas 1 a 4: S/Y = Sí, N = No
        if (key === 's' || key === 'y') {
          e.preventDefault();
          this.dom.btnOption1.focus();
          this.handleOptionSelection(0);
        } else if (key === 'n') {
          e.preventDefault();
          this.dom.btnOption2.focus();
          this.handleOptionSelection(1);
        }
      }
    });
  }

  /**
   * Reproduce sonido si el audio está activo
   */
  playSound(type, param) {
    if (!window.terminalAudio) return;
    switch (type) {
      case 'click':
        window.terminalAudio.playKeyClick();
        break;
      case 'hover':
        window.terminalAudio.playHover();
        break;
      case 'confirm':
        window.terminalAudio.playConfirm();
        break;
      case 'processing':
        window.terminalAudio.playProcessing();
        break;
      case 'scoreTick':
        if (window.terminalAudio.playScoreTick) {
          window.terminalAudio.playScoreTick();
        } else {
          window.terminalAudio.playKeyClick();
        }
        break;
      case 'statusResult':
        if (window.terminalAudio.playStatusResult) {
          window.terminalAudio.playStatusResult(param);
        } else {
          window.terminalAudio.playConfirm();
        }
        break;
      case 'error':
        window.terminalAudio.playSystemError();
        break;
    }
  }

  /**
   * Inicia el flujo de preguntas
   */
  startQuestionFlow() {
    this.currentQuestionIndex = 0;
    this.userAnswers = [];
    this.totalSuspicionScore = 0;
    this.isProcessing = false;
    this.updateSuspicionDisplay();
    this.updateAnsweredCounter();
    this.cleanBodyModes();

    if (window.terminalAudio) {
      window.terminalAudio.startScannerHum();
    }

    if (this.dom.subjectStatus) {
      this.dom.subjectStatus.textContent = "IDENTIFICACIÓN EN CURSO";
    }

    // Transición GSAP: Salida de Pantalla Inicial -> Entrada de Preguntas
    const tl = gsap.timeline();
    tl.to(this.dom.screenIntro, {
      opacity: 0,
      scale: 0.96,
      duration: 0.35,
      ease: "power2.in",
      onComplete: () => {
        this.dom.screenIntro.classList.remove('active');
        this.dom.screenIntro.setAttribute('aria-hidden', 'true');
        this.dom.screenQuestions.classList.add('active');
        this.dom.screenQuestions.removeAttribute('aria-hidden');
      }
    });

    tl.fromTo(this.dom.screenQuestions, 
      { opacity: 0, scale: 1.04 },
      { 
        opacity: 1, 
        scale: 1, 
        duration: 0.45, 
        ease: "power2.out",
        onComplete: () => {
          this.displayCurrentQuestion(false);
          this.dom.btnOption1.focus();
        }
      }
    );

    this.logTerminal("INICIANDO PROTOCOLO DE CLASIFICACIÓN MIGRATORIA...");
  }

  /**
   * Presenta la pregunta actual y adapta los botones con animaciones GSAP
   */
  displayCurrentQuestion(withGlitch = true) {
    const q = this.questions[this.currentQuestionIndex];
    const questionNumberStr = `0${q.id}/05`;

    // Actualizar Textos
    this.dom.questionCounter.textContent = questionNumberStr;
    this.dom.questionText.textContent = q.text;
    this.dom.questionSubtext.textContent = q.subtext;

    // Configurar botones dinámicos (SÍ/NO o POR ELECCIÓN/POR NECESIDAD)
    const opt1 = q.options[0];
    const opt2 = q.options[1];

    this.dom.btnText1.textContent = opt1.text;
    this.dom.btnKey1.textContent = `[${opt1.key}]`;
    this.dom.btnText2.textContent = opt2.text;
    this.dom.btnKey2.textContent = `[${opt2.key}]`;

    // Ajustar clase si son botones anchos (Pregunta 5)
    if (q.id === 5) {
      this.dom.btnOption1.classList.add('wide-btn');
      this.dom.btnOption2.classList.add('wide-btn');
    } else {
      this.dom.btnOption1.classList.remove('wide-btn');
      this.dom.btnOption2.classList.remove('wide-btn');
    }

    // Actualizar Barra de Progreso
    const percentage = ((this.currentQuestionIndex + 1) / this.questions.length) * 100;
    this.dom.progressBarFill.style.width = `${percentage}%`;

    // Actualizar ticks visuales
    const ticks = document.querySelectorAll('.progress-ticks .tick');
    ticks.forEach((tick, i) => {
      if (i <= this.currentQuestionIndex) {
        tick.classList.add('active');
      } else {
        tick.classList.remove('active');
      }
    });

    if (this.reducedMotion || !withGlitch) return;

    // Animación GSAP de entrada de la tarjeta
    gsap.fromTo(this.dom.questionCard,
      { opacity: 0, y: -15, filter: "blur(4px)" },
      { opacity: 1, y: 0, filter: "blur(0px)", duration: 0.45, ease: "power2.out" }
    );

    // Animación en los botones de respuesta
    gsap.fromTo([this.dom.btnOption1, this.dom.btnOption2],
      { opacity: 0, y: 10 },
      { opacity: 1, y: 0, duration: 0.35, stagger: 0.08, ease: "power2.out" }
    );
  }

  /**
   * Manejo de selección de respuesta
   */
  handleOptionSelection(optionIndex) {
    if (this.isProcessing) return;
    this.isProcessing = true;

    const currentQ = this.questions[this.currentQuestionIndex];
    const selectedOption = currentQ.options[optionIndex];

    // Acumular puntos de sospecha
    this.totalSuspicionScore += selectedOption.points;

    // Guardar respuesta del usuario
    this.userAnswers.push({
      questionId: currentQ.id,
      questionText: currentQ.text,
      criteriaLabel: currentQ.criteriaLabel,
      answerText: selectedOption.text,
      pointsScored: selectedOption.points
    });

    this.playSound('click');
    this.updateSuspicionDisplay();
    this.updateAnsweredCounter();
    this.logTerminal(`> [RTA ${currentQ.id}]: ${selectedOption.text} (+${selectedOption.points} PTS SOSPECHA)`);

    // Micro-animación de procesamiento y análisis
    this.dom.processingOverlay.classList.add('show');
    this.dom.processingSub.textContent = `SUMANDO +${selectedOption.points} PTS AL VECTOR DE SOSPECHA`;
    this.playSound('processing');

    // Aceleración temporal del láser para simular escaneo activo
    if (this.laserTimeline && !this.reducedMotion) {
      this.laserTimeline.timeScale(3);
    }

    setTimeout(() => {
      // Restaurar velocidad del láser
      if (this.laserTimeline && !this.reducedMotion) {
        this.laserTimeline.timeScale(1);
      }
      this.dom.processingOverlay.classList.remove('show');

      // Avanzar a la siguiente pregunta o a la secuencia de escaneo final
      this.currentQuestionIndex++;
      if (this.currentQuestionIndex < this.questions.length) {
        this.isProcessing = false;
        this.displayCurrentQuestion(true);
      } else {
        this.triggerFinalScan();
      }
    }, 850);
  }

  /**
   * Actualiza el indicador visual de nivel de sospecha progresivamente
   */
  updateSuspicionDisplay() {
    const score = this.totalSuspicionScore;
    const scoreStr = String(score).padStart(2, '0');

    if (this.dom.suspicionScoreVal) {
      this.dom.suspicionScoreVal.textContent = scoreStr;
    }
    if (this.dom.telemetrySuspicion) {
      this.dom.telemetrySuspicion.textContent = `${scoreStr} / 85 PTS`;
    }

    // Calcular ancho proporcional (máximo 85 puntos)
    const fillPercent = Math.min(100, Math.round((score / 85) * 100));
    if (this.dom.suspicionMeterFill) {
      this.dom.suspicionMeterFill.style.width = `${fillPercent}%`;

      // Clases dinámicas de color según umbral
      this.dom.suspicionMeterFill.classList.remove('warn', 'danger');
      if (score > 50) {
        this.dom.suspicionMeterFill.classList.add('danger');
      } else if (score > 20) {
        this.dom.suspicionMeterFill.classList.add('warn');
      }
    }
  }

  /**
   * Secuencia de Escaneo Final y Resultado
   * Cumple con la sección 4: Contador de puntos, silueta, indicadores cambiantes y clasificación
   */
  triggerFinalScan() {
    this.logTerminal("TODAS LAS RESPUESTAS REGISTRADAS.");
    this.logTerminal("INICIANDO SECUENCIA DE ESCANEO FINAL...");

    // Transición a la pantalla de Resultado Final
    this.dom.screenQuestions.classList.remove('active');
    this.dom.screenQuestions.setAttribute('aria-hidden', 'true');
    this.dom.screenFinalResult.classList.add('active');
    this.dom.screenFinalResult.removeAttribute('aria-hidden');

    // Acelerar láser durante el escaneo final
    if (this.laserTimeline && !this.reducedMotion) {
      this.laserTimeline.timeScale(2.5);
    }

    // Resetear textos y estilos del resultado mientras se procesa
    this.dom.resultStamp.className = "result-stamp";
    this.dom.resultStamp.textContent = "PROCESANDO...";
    this.dom.resultSubBadge.textContent = "CRUZANDO DATOS CON ARCHIVOS CLASIFICADOS";
    this.dom.finalScoreDisplay.textContent = "00 / 85 PTS";
    this.dom.criteriaSummaryGrid.innerHTML = "";
    this.dom.btnRevealError.style.opacity = "0";
    this.dom.btnRevealError.style.pointerEvents = "none";

    const phases = [
      { text: "PROCESANDO RESULTADOS...", delay: 200, threat: "ANALIZANDO SUJETO" },
      { text: "CRUZANDO INFORMACIÓN...", delay: 1100, threat: "CRUZANDO INFORMACIÓN" },
      { text: "DETERMINANDO NIVEL DE AMENAZA...", delay: 2000, threat: "DETERMINANDO AMENAZA" },
      { text: "CLASIFICACIÓN EN CURSO...", delay: 2900, threat: "CLASIFICACIÓN EN CURSO" }
    ];

    phases.forEach(p => {
      setTimeout(() => {
        if (this.dom.finalScanPhaseMsg) {
          this.dom.finalScanPhaseMsg.textContent = p.text;
        }
        if (this.dom.threatLevel) {
          this.dom.threatLevel.textContent = p.threat;
        }
        this.playSound('processing');
      }, p.delay);
    });

    // Contador de puntos progresivo (0 -> totalSuspicionScore)
    setTimeout(() => {
      let currentTally = 0;
      const targetScore = this.totalSuspicionScore;
      const step = Math.max(1, Math.ceil(targetScore / 25));

      const interval = setInterval(() => {
        currentTally += step;
        if (currentTally >= targetScore) {
          currentTally = targetScore;
          clearInterval(interval);
        }
        this.dom.finalScoreDisplay.textContent = `${String(currentTally).padStart(2, '0')} / 85 PTS`;
        this.playSound('scoreTick');
      }, 50);
    }, 1800);

    // Revelar clasificación final según los rangos establecidos
    setTimeout(() => {
      this.revealClassificationResult();
    }, 3600);
  }

  /**
   * Despliega la clasificación obtenida (HUMANO CONFIRMADO, SUJETO BAJO INVESTIGACIÓN o ALIEN DETECTADO)
   */
  revealClassificationResult() {
    const score = this.totalSuspicionScore;
    let status = 'HUMANO';
    let stampText = 'HUMANO CONFIRMADO';
    let subtext = 'IDENTIDAD HUMANA CONFIRMADA';
    let stampClass = 'stamp-human';
    let bodyMode = 'mode-human';

    if (score >= 51) {
      status = 'ALIEN';
      stampText = 'ALIEN DETECTADO';
      subtext = 'AMENAZA IDENTIFICADA';
      stampClass = 'stamp-alien';
      bodyMode = 'mode-alien';
    } else if (score >= 21) {
      status = 'INVESTIGACIÓN';
      stampText = 'SUJETO BAJO INVESTIGACIÓN';
      subtext = 'IDENTIDAD BAJO INVESTIGACIÓN';
      stampClass = 'stamp-review';
      bodyMode = 'mode-review';
    }

    // Aplicar modo al cuerpo
    this.cleanBodyModes();
    this.dom.body.classList.add(bodyMode);

    // Restaurar láser
    if (this.laserTimeline && !this.reducedMotion) {
      this.laserTimeline.timeScale(1);
    }

    // Configurar Sello y Subtítulo
    this.dom.finalScanPhaseMsg.textContent = `EVALUACIÓN CONCLUIDA: ${stampText}`;
    this.dom.resultStamp.className = `result-stamp ${stampClass}`;
    this.dom.resultStamp.textContent = stampText;
    this.dom.resultSubBadge.textContent = subtext;

    if (this.dom.threatLevel) {
      this.dom.threatLevel.textContent = subtext;
    }

    // Construir tabla de criterios evaluados
    this.dom.criteriaSummaryGrid.innerHTML = "";
    this.userAnswers.forEach(ans => {
      const row = document.createElement('div');
      row.className = 'criteria-row';
      row.innerHTML = `
        <span><strong>${ans.criteriaLabel}:</strong> ${ans.answerText}</span>
        <span class="criteria-pts" style="color: ${ans.pointsScored > 0 ? (ans.pointsScored >= 20 ? 'var(--color-danger)' : 'var(--color-accent-amber)') : 'var(--color-primary)'}">
          +${ans.pointsScored} PTS
        </span>
      `;
      this.dom.criteriaSummaryGrid.appendChild(row);
    });

    this.playSound('statusResult', status);

    // Animación de aparición del resultado
    if (!this.reducedMotion) {
      gsap.fromTo(this.dom.resultStamp,
        { scale: 0.8, opacity: 0, rotate: -8 },
        { scale: 1, opacity: 1, rotate: -2, duration: 0.65, ease: "back.out(1.7)" }
      );
      gsap.to(this.dom.btnRevealError, {
        opacity: 1,
        duration: 0.4,
        delay: 0.3,
        onStart: () => {
          this.dom.btnRevealError.style.pointerEvents = "auto";
          this.dom.btnRevealError.focus();
        }
      });
    } else {
      this.dom.btnRevealError.style.opacity = "1";
      this.dom.btnRevealError.style.pointerEvents = "auto";
      this.dom.btnRevealError.focus();
    }

    this.logTerminal(`CLASIFICACIÓN FINAL: ${stampText} (${score} PTS)`);
  }

  /**
   * Ruptura Visual y Revelación Final: El Error del Sistema
   * Cumple con la sección 5: Glitch, distorsión, fragmentación de silueta y mensajes de crítica institucional
   */
  triggerVisualRupture() {
    this.logTerminal("PARADOJA DETECTADA EN LA BASE DE REGLAS...");
    this.logTerminal("FALLA ESTRUCTURAL: RUPTURA COGNITIVA");

    this.playSound('error');

    // Efecto de distorsión en el contenedor y silueta
    if (this.dom.scannerViewport) {
      this.dom.scannerViewport.classList.add('visual-rupture-active');
    }
    if (this.dom.silhouetteSvg) {
      this.dom.silhouetteSvg.classList.add('silhouette-corrupted');
    }

    // Glitch en toda la pantalla con GSAP
    if (!this.reducedMotion) {
      gsap.to(this.dom.screenFinalResult, {
        x: () => gsap.utils.random(-12, 12),
        y: () => gsap.utils.random(-8, 8),
        duration: 0.05,
        repeat: 8,
        yoyo: true,
        ease: "none"
      });
    }

    // Transición a la pantalla de Error
    setTimeout(() => {
      this.dom.screenFinalResult.classList.remove('active');
      this.dom.screenFinalResult.setAttribute('aria-hidden', 'true');
      this.dom.screenError.classList.add('active');
      this.dom.screenError.removeAttribute('aria-hidden');

      this.cleanBodyModes();
      this.dom.body.classList.add('alarm-active');

      if (this.dom.scannerViewport) {
        this.dom.scannerViewport.classList.remove('visual-rupture-active');
      }

      // Animación contundente del mensaje central y punchline
      if (!this.reducedMotion) {
        const tl = gsap.timeline();
        tl.fromTo(this.dom.revelationQuestion,
          { opacity: 0, y: -20, filter: "blur(6px)" },
          { opacity: 1, y: 0, filter: "blur(0px)", duration: 0.6, ease: "power2.out" }
        );
        tl.fromTo(this.dom.errorHeadline,
          { opacity: 0, scale: 0.88 },
          { opacity: 1, scale: 1, duration: 0.7, ease: "back.out(1.4)" },
          "-=0.2"
        );
        tl.fromTo(this.dom.finalPunchline,
          { opacity: 0, scale: 1.15 },
          { opacity: 1, scale: 1, duration: 0.5, ease: "power2.out" },
          "-=0.2"
        );
      }

      this.dom.btnRetry.focus();
    }, 650);
  }

  /**
   * Reinicia la experiencia al inicio del cuestionario (Pregunta 1)
   */
  resetToQuestions() {
    this.cleanBodyModes();
    this.dom.screenError.classList.remove('active');
    this.dom.screenError.setAttribute('aria-hidden', 'true');
    if (this.dom.silhouetteSvg) {
      this.dom.silhouetteSvg.classList.remove('silhouette-corrupted');
    }
    this.startQuestionFlow();
  }

  /**
   * Regresa la experiencia a la pantalla inicial (Standby)
   */
  resetToIntro() {
    this.cleanBodyModes();
    this.dom.screenError.classList.remove('active');
    this.dom.screenError.setAttribute('aria-hidden', 'true');
    this.dom.screenFinalResult.classList.remove('active');
    this.dom.screenFinalResult.setAttribute('aria-hidden', 'true');
    this.dom.screenQuestions.classList.remove('active');
    this.dom.screenQuestions.setAttribute('aria-hidden', 'true');

    this.dom.screenIntro.classList.add('active');
    this.dom.screenIntro.removeAttribute('aria-hidden');

    if (this.dom.silhouetteSvg) {
      this.dom.silhouetteSvg.classList.remove('silhouette-corrupted');
    }

    this.currentQuestionIndex = 0;
    this.userAnswers = [];
    this.totalSuspicionScore = 0;
    this.isProcessing = false;
    this.updateSuspicionDisplay();
    this.updateAnsweredCounter();

    if (this.dom.subjectStatus) {
      this.dom.subjectStatus.textContent = "ANALIZANDO SUJETO";
    }
    if (this.dom.threatLevel) {
      this.dom.threatLevel.textContent = "IDENTIFICACIÓN EN CURSO";
    }

    this.logTerminal("SISTEMA RESTABLECIDO A MODO ESPERA");
    this.dom.btnStartScan.focus();
  }

  /**
   * Limpia clases de modos de color del body
   */
  cleanBodyModes() {
    this.dom.body.classList.remove('mode-human', 'mode-review', 'mode-alien', 'alarm-active');
  }

  /**
   * Actualiza el contador de respuestas registradas en la telemetría lateral
   */
  updateAnsweredCounter() {
    if (this.dom.answeredCount) {
      this.dom.answeredCount.textContent = `${this.userAnswers.length} / ${this.questions.length} REGISTRADAS`;
    }
  }

  /**
   * Agrega un log con scroll automático a la consola lateral de la terminal
   */
  logTerminal(message) {
    if (!this.dom.terminalLogs) return;
    const p = document.createElement('p');
    p.textContent = `> ${message}`;
    this.dom.terminalLogs.appendChild(p);

    // Mantener solo los últimos 8 registros
    while (this.dom.terminalLogs.children.length > 8) {
      this.dom.terminalLogs.removeChild(this.dom.terminalLogs.firstChild);
    }

    this.dom.terminalLogs.scrollTop = this.dom.terminalLogs.scrollHeight;
  }
}

// Inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
  window.alienScannerApp = new AlienScannerExperience();
});
